export interface Command{
    id?:number;
    weaponSystem:string;
    battleship:string;
    target:string;
    quantity:number;
    rate:number;
}